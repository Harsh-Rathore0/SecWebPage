document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (!username || !password) {
    alert("All fields are required!");
  } else {
    alert("Login Successful!");
    // Proceed with backend API call
  }
});

document.getElementById("registrationForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const username = document.getElementById("usernameReg").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("passwordReg").value;
  const role = document.getElementById("role").value;

  if (!username || !email || !password || !role) {
    alert("All fields are required!");
    return;
  }

  if (!/\S+@\S+\.\S+/.test(email)) {
    alert("Invalid email format!");
    return;
  }

  if (password.length < 8) {
    alert("Password must be at least 8 characters long!");
    return;
  }

  alert("Registration Successful!");
  // Proceed with backend API call
});
